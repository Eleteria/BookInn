import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "BookInn",
  description: "BookInn hotel reservation system — staff portal",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
